
	window.onload=function(){
				var ul=document.querySelector("ul");//获取ul
				var div=document.querySelector("#box div");//获取底部文字的div
				var n=0;		//用来存储图片走的个数
				var timer;      //全局变量 用来存放定时器返回值
				
				//底部文字数组
				var textArr=[
					{"title":'盛惠而来',"content":'京东携手天天果园百万车厘子，29元包邮畅想'},
					{"title":'荣耀7',"content":'有点不同，0元预约，免费抽奖1999元'},
					{"title":'老板购物节',"content":'2015我要更省，老板XX购物节精彩来袭'},
					{"title":'送钱送美酒',"content":'大盘让我心碎，我在京东买醉送钱送美酒'},
					{"title":'玩转暑假',"content":'追风少年，联想拯救者全国独家抢购'},
					{"title":'游园门票',"content":'奔跑吧周末游游园门票一元秒杀'}
				];
				
				//把ul的内容复制一份
				ul.innerHTML+=ul.innerHTML;
				
				//将所有的li都排在一行
				var lis=document.querySelectorAll("li");
				//设置一个li的宽度
				var w=parseInt(getComputedStyle(lis[0]).width);
				//所有li的宽度
				ul.style.width=w*lis.length+'px';
				
				//把文字添加到图片上
				div.innerHTML='<h3>'+textArr[0].title+'</h3><p>'+textArr[0].content+'</p>';
				
				//开启一个定时器，让图片不断的走
				timer=setInterval(pic,3000);
				
				function pic(){
					n++;//记录图片走了多少张
					//让文字先运动到下面
					move(div,{bottom:-70},500,'linear',function(){
						//当文字已经运动消失了，这个时候该运动ul
						move(ul,{left:-730*n},1000,'linear',function(){
							//是否为第一章 是 就把ul拉回来
							if(n==lis.length/2){
								//复制的ul 已经走完，要让ul回到0
								ul.style.left=0;
								n=0;		//n不在自增
							}
							//在文字上去之前应该把内容改了
							div.innerHTML='<h3>'+textArr[n].title+'</h3><p>'+textArr[n].content+'</p>';
							//当ul走完了一个，这个时候需要让文字块移动上去
							move(div,{bottom:0},500,'linear');
						});
					});
				}
				//鼠标移入事件
				ul.onmousemove=function(){
					clearInterval(timer);
				}
				//鼠标移出事件
				ul.onmouseout=function(){
				   timer=setInterval(pic,2000)
				}
			}
	

