window.onload=function(){
		//  1、点击展开按钮，“查找”与“替换”显示
		var bropen=document.getElementById("bropen");//展开按钮
		var brseek=document.getElementById("brseek");//查找
		var brth=document.getElementById("brth");//替换

		//功能区
		var bttom=document.getElementById("bttom");//父级div
		var bmseek=document.getElementById("bmseek");//bmseek--查找
		var bmth=document.getElementById("bmth");//bmth--替换
		
		var btmp1=document.getElementById("btmp1");//查找按钮对应的显示区P的id
		var btmp2=document.getElementById("btmp2");//替换按钮对应的显示区P的id
		
		
		var bpmseek=document.getElementById("bpmseek");//查找对应的显示区的 查找按钮
		var bpmth=document.getElementById("bpmth");//替换对应的显示区的替换按钮
		
		var bmimg=document.getElementById("bmimg");//功能区关闭按钮
		
		var bmtext1=document.getElementById("bmtext1");//文本框
	  	var bmtext2=document.getElementById("bmtext2");//文本框
	  	var bmtxtid=document.getElementById("bmtext");//文本框
		
		
		var context=document.getElementById("context");//内容id
	    var str=context.innerHTML;//获取内容  全局变量
	    
	    
		showhiden();//加载时禁用的区域 的方法
		
		//查找按钮显示隐藏功能区通用方法
		function seekClick(){
			bttom.style.display="block";//显示
			bmseek.style.backgroundColor="#a8a6f6";//设置按钮背景
			bpmseek.style.backgroundColor="#a8a6f6";//设置按钮背景
			
			bmth.style.backgroundColor="";//清空按钮背景
			
			btmp2.style.display="none";//隐藏
			btmp1.style.display="block";//显示
		}
		//替换按钮显示隐藏功能区通用方法
		function thClick(){
			bttom.style.display="block";//
			bmth.style.backgroundColor="#9fe7a9";
			bpmth.style.backgroundColor="#9fe7a9";
			
			bmseek.style.backgroundColor='';
			
			btmp1.style.display="none";
			btmp2.style.display="block";
			
			bmtext1.value="";//文本框为空
			bmtext2.value="";//文本框为空
			bmtxtid.value="";//文本框为空
			
		}
		
		//页面加载时禁用区域通用方法
		function showhiden(){
			brseek.style.display="none";
			brth.style.display="none";
			bttom.style.display="none";
			
		}
		
		//展开按钮点击事件
		bropen.onclick=function(){
			brseek.style.display="block";
		    brth.style.display="block";
		}
		//查找按钮点击事件
		brseek.onclick=function(){
			//点击“查找”按钮，下面的功能区域显示，并且显示的是查找的功能
			seekClick();
		}
		
		//功能区brth替换按钮切换可视区事件
		bmth.onclick=function(){
			thClick();
			context.innerHTML=str;
		}
		//功能区bmseek查找按钮切换可视区事件
		bmseek.onclick=function(){	
			seekClick()
		}	
		//替换按钮点击事件
		brth.onclick=function(){
			//点击“替换”按钮，下面的功能区域显示，并且显示的是替换的功能
		thClick();
			context.innerHTML=str;
		}
		//bmimg功能区关闭事件
		bmimg.onclick=function(){
			showhiden()
		}
	    //功能区查找按钮点击事件
		bpmseek.onclick=function(){
			var context=document.getElementById("context");//内容id
	        var str=context.innerHTML;//获取内容
			var bmtext=bmtxtid.value;//获取文本框的值
			var inhtmlColor="";//变量，用来存储改变后的字符串
			//如果为空（去掉输入的空格）
			if(bmtext.trim()==""){
				alert("请输入内容");
			}
			//不为空
			else{
				//根据文本框的内容 搜索  并返回下标值
				var revalue=str.indexOf(bmtext);
				//大于0  表示有这个字符串
			    if(revalue>=0){
			    	//以获取到的文本框字符串为分隔符 分割成数组进行组合
					var array=str.split(bmtext);
					//循环
					for(var i=0;i<array.length;i++){
						//最后一个不拼接
						if(i==array.length-1){
						 inhtmlColor+=array[array.length-1];	
						}
						else{
							inhtmlColor+=array[i]+"<span style='background-color:yellow;'>"+bmtext+"</span>"; 
						}
					}
					//将组成的字符串  放到div中
				   context.innerHTML=inhtmlColor;
				}
			    //无字符串
			    else{
			    	alert("你输入的内容未找到");
			    	return;
			    }
				
			}
			
		}
	    //功能区替换按钮点击事件
	    bpmth.onclick=function(){
	  	var contextth=document.getElementById("context");//内容id
	    var strth=context.innerHTML;//获取内容
	  	var strbmtext1=bmtext1.value;//查找的文本框的值
	  	var strbmtext2=bmtext2.value;//替换的文本框
	  	var delstr="";
	  	//两个框里都没有内容
	  	if(strbmtext1.trim()==""&&strbmtext2.trim()==""){
	  		alert("请输入要替换的内容");
	  		return;
	  	}
	  	//第一个框里有内容，但是内容在上面文字里没的到，同时第二个框里没内容
	  	if(strbmtext1.trim()!=""&&strbmtext2.trim()==""){
	  		var retxt=strth.indexOf(strbmtext1);//是否存在搜索的字符串  根据返回值判断
	  		if(retxt<0){
	  			alert("你输入的内容未找到");
			    	return;
	  		}
	  		//第一个框里有内容，在上面的文字里有找到，同时第二个框里没内容
	  		else{
	  			if(confirm("确认删除吗？")){
	  				//delstr=str.replace(strbmtext1,'');//将制定字符串换成空
	  				delstr=strth.split(""+strbmtext1+"").join("");//将数组转换为字符串
	  				contextth.innerHTML=delstr;
	  			}
	  			else{
	  				bmtext1.value="";//清空文本框内容
	  				bmtext2.value="";//
	  			}
	  		}
	  	}
	  	//第一个不为空  第二个不为空
	  	if(strbmtext1.trim()!=""&&strbmtext2.trim()!=""){
	  		var retxt=strth.indexOf(strbmtext1);//根据返回值  判断是否包含目标字符串
	  		//再次判断第一个文本框的内容是否存在
	  		if(retxt<0){
	  			alert("你输入的内容未找到");
			   return;
	  		}
	  		//存在
	  		else{
	  			//以输入框的内容为分隔符 分割成数组
	  			var array=strth.split(strbmtext1);
	  			
	  			//循环替换内容
	  			for(var i=0;i<array.length;i++){
	  				//避免后面多拼接一次
	  				if(i==array.length-1){
	  					delstr+=array[array.length-1];
	  				}
	  				else{
	  					delstr+=array[i]+strbmtext2; 
	  				}
	  			}
	  			contextth.innerHTML=delstr;//拼接好的内容重新放到div中	  			
	  		}
	  	}
	  	
	  }
}