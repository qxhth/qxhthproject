window.onload=function(){
	
	var box2=document.getElementById("box2");
	var box1=document.getElementById("box1");
	var txt=document.getElementById("text");
	var content=document.getElementById("content");
	var topTriangle=document.getElementById("top-Triangle");
	var bottomTriangle=document.getElementById("bottom-Triangle");
	var scrol=document.getElementById("scrol");
	
	
	//上方按钮条点击事件
	topTriangle.addEventListener("click",function(ev){
		//调用滚轮公共方法--每次向上走30px
		var scrolltop=box2.offsetTop;
		if(scrolltop>10){
			scrolltop-=30;
		}
		else{
			scrolltop=-30
		}
		scrollReletive(scrolltop);
		ev.stopPropagation();
	},false);
	//下方按钮鼠标按下事件
	topTriangle.addEventListener("mousedown",function(ev){
		topTriangle.style.background="blue";
		ev.stopPropagation();
	},false);
	topTriangle.addEventListener("mouseup",function(ev){
		topTriangle.style.background="";
	},false);

	//下方按钮点击事件
	bottomTriangle.addEventListener("click",function(ev){
		var scrolltop=box2.offsetTop;
		if(scrolltop>10){
			scrolltop+=30;
		}
		else{
			scrolltop=30
		}
		scrollReletive(scrolltop);
		//阻止冒泡
		ev.stopPropagation();
		
	},false);
	bottomTriangle.addEventListener("mousedown",function(ev){
		bottomTriangle.style.background="blue";
	},false);
	bottomTriangle.addEventListener("mouseup",function(ev){
		bottomTriangle.style.background="";
	},false);
	
	
	//滚动块的点击事件
	//1、鼠标拖动蓝色滑块，内容区域滚动
	box2.onmousedown=function(ev){
		//记录点击的地方距离box2顶部的一段距离
		var disy=ev.clientY-box2.offsetTop;

		document.onmousemove=function(ev){
			
			//记录滚动条滚动的的距离
			var t=ev.clientY-disy
			//调用滚轮公共方法
			scrollReletive(t);
			ev.cancelBubble=true
		}
		document.onmouseup=function(){
			document.onmousemove=null;
		}
		return false;
		
	};
	//调用鼠标滚轮事件方法
	//2、鼠标放在文字区域与滚动条区域，滚动滚轮都可以滚动
	myScroll(scrol,function(){
		//每次调用时都要获取滚动块的位置
		var scrolltop=box2.offsetTop;
		if(scrolltop>10){
			
			scrolltop-=30;
		}
		else{
			scrolltop=-30
		}
		scrollReletive(scrolltop);
		
	},function(){
        //向下翻滚30px
       var scrolltop=box2.offsetTop;
		if(scrolltop>10){
			scrolltop+=30;
		}
		else{
			scrolltop=30
		}
		scrollReletive(scrolltop);
	});
	 //鼠标按下滑块区域，滑块的中心滚动到鼠标按下的位置
	 //3、鼠标按下滑块区域，滑块的中心滚动到鼠标按下的位置
	 box1.addEventListener("click",function(ev){

         //鼠标按下的位置 减去box1的top在减去滑块本身的一半高度 
         var t=ev.clientY-box1.offsetTop-box2.clientHeight/2;
         var scrol=ev.clientY-box1.offsetTop-box2.clientHeight;

         //是否超过上下按钮的位置
         if(t<10){
         	//滚动块在最上端的最小距离
         	 t=10;
         	
         }
         if(t>460){
         	t=460;
         	//加上底部按钮的高度10px才是右侧正确滚动的比例
         	scrol=470;
         }
        scrollReletive(scrol);
        box2.style.top=t+"px";
		ev.stopPropagation();
	 },false);
	
	
	 //滚动条滚动公共方法
	//reletive--参数表示传入的滚动条滚动的距离
	function scrollReletive(reletive){
		//声明变量--表示比例    
		var scale;
        scale=reletive/(box1.clientHeight-box2.clientHeight);
		if(reletive<topTriangle.clientHeight){
			//表示超出box1
			reletive=topTriangle.clientHeight;
			//滚动条走到了最初始的位置，那么左侧内容对应在最上面
			scale=0;
		}
		else if(reletive>box1.clientHeight-box2.clientHeight-bottomTriangle.clientHeight){
			reletive=box1.clientHeight-box2.clientHeight-bottomTriangle.clientHeight;
			//滚动条走到了最下面的位置，那么左侧内容对应在最下面
			scale=1;
		}
		//左侧内容块走的距离
		content.style.top=(txt.clientHeight-content.clientHeight)*scale+"px";
        //滚动块的距离
		box2.style.top=reletive+"px";
	};
	
	//滚轮事件
	//滚轮公共方法
	function myScroll(obj,upfn,downfn){
		obj.onmousewheel=fn;
		obj.addEventListener("DOMMouseScroll",fn);
		function fn(ev){
			if(ev.wheelDelta>0||ev.detail<0){
				upfn();
			}
			else{
				downfn();
			}
			ev.preventDefault();
		}
		
		return false;
	};
}
