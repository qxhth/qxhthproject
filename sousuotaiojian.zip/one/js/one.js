window.onload=function(){
	var branda=document.querySelectorAll("#brand a");
	var price=document.querySelectorAll("#price a");
	var size=document.querySelectorAll("#size a");
	var card=document.querySelectorAll("#card a");
	var selcond=document.getElementById("selcond");
	var brandid=document.getElementById("brand");
	var priceid=document.getElementById("price");
	var sizeid=document.getElementById("size");
	var cardid=document.getElementById("card");
	
	addCard(branda,"strbranda",brandid);
	addCard(price,"strprice",priceid);
	addCard(size,"strsize",sizeid);
	addCard(card,"strcard",cardid);
	
	
	/*
	 *添加筛选条件公共方法
	 *obj     传入的点击对象
	 *str     传入的特定标识，用来区别添加的条件
	 */
	function addCard(obj,str){
		for(var i=0;i<obj.length;i++){
			obj[i].onclick=function(){
				var br=document.getElementById(str);
				
				if(br){
					var br=document.getElementById(str);
					br.innerHTML=this.innerHTML+"<a href='#'></a>";
					this.style.color="red";
					//修改颜色
					updateStyle(this);
			        var las=document.querySelectorAll("#selcond li a");
				    var ul=document.querySelector("ul");
				    //删除元素,并修改颜色
					removechild(las,ul);
				}
				else{
					this.style.color="red";
					//创建一个新的子节点
					var li=document.createElement("li");
					li.setAttribute("name",str);
					li.innerHTML="<span id="+str+">"+this.innerHTML+"<a href='#'></a></span>";
					//在页面中添加子节点子元素
					selcond.appendChild(li);
					var lis=document.querySelectorAll("#selcond li");
			        var las=document.querySelectorAll("#selcond li a");
				    var ul=document.querySelector("ul");
                    removechild(las,ul);
				}
			}
		}
	}
	
	/*删除节点操作公共方法*/
	function removechild(child,childparent){
	    for(var i=0;i<child.length;i++){
			child[i].onclick=function(){
						//通过a找到父级，删除li
			var aparent=this.parentNode.parentNode;
			childparent.removeChild(aparent);
						
			if(aparent.getAttribute("name")=="strbranda"){
							
				updatechildstyle(brandid);
			}
			if(aparent.getAttribute("name")=="strprice"){
				updatechildstyle(priceid);
			}
			if(aparent.getAttribute("name")=="strsize"){
				updatechildstyle(sizeid);
			}
			if(aparent.getAttribute("name")=="strcard"){
				updatechildstyle(cardid);
			}
		}
	}
}
					
	/*点击后的文字颜色处理方法*/
	function updateStyle(elm){
		var p=elm.parentNode.children;
		for(var i =0;i<p.length;i++){
			if(p[i] !== elm && i!=0)
	  		{
	  			p[i].style.color="#252525";
	  		}
		}
	}
	/*删除所选条件后更改文字颜色--方法*/
	function updatechildstyle(elm){
		var child=elm.childNodes;
		for(var i =1;i<child.length;i++){
			if(child[i].nodeType==1){
				 child[i].style.color="#252525";
			}

		}
	}
}
